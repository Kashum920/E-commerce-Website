import React, { useState, useEffect, useContext, useRef } from 'react';
import './Navbar.css';

import logo from '../Assets/logo.png';
import cart_icon from '../Assets/cart_icon.png';
import { Link, useLocation } from 'react-router-dom';
import { ShopContext } from '../../Context/ShopContext';
import nav_dropdown from '../Assets/nav_dropdown.png'

export const Navbar = () => {

    const {getTotalCartItems} = useContext(ShopContext);
    const location = useLocation();

    // navbar toggle
    const menuRef = useRef();

    const dropdown_toggle = (e) => {
        menuRef.current.classList.toggle('nav-menu-visible');
        e.target.classList.toggle('open');
    }

    const [menu, setMenu] = useState(() => {
        const storedMenu = localStorage.getItem('activeMenu');
        return storedMenu || 'shop'; // Default to 'shop' if no stored value
    });

    const handleMenuClick = (menuItem) => {
        setMenu(menuItem);
    };

    const handleCartClick = () => {
        // Clear menu state when cart is clicked
        setMenu('');
    };

    useEffect(() => {
        localStorage.setItem('activeMenu', menu);
    }, [menu]);

    const isSpecialPage = location.pathname === '/login' || location.pathname === '/cart';

    return (
        <div className='navbar'>
            <div className='nav-logo'>
                <img src={logo} alt="" />
            </div>

            <img className='nav-dropdown' onClick={dropdown_toggle} src={nav_dropdown} alt="" />

            <ul ref={menuRef} className='nav-menu'>
                <li onClick={() => handleMenuClick("shop")}>
                    <Link style={{ textDecoration:'none' }} to='/'>Shop</Link>
                    {!isSpecialPage && menu === "shop" ? <hr /> : null}
                </li>
                <li onClick={() => handleMenuClick("mens")}>
                    <Link style={{ textDecoration:'none' }} to='/mens'>Men</Link>
                    {!isSpecialPage && menu === "mens" ? <hr /> : null}
                </li>
                <li onClick={() => handleMenuClick("womens")}>
                    <Link style={{ textDecoration:'none' }} to='/womens'>Women</Link>
                    {!isSpecialPage && menu === "womens" ? <hr /> : null}
                </li>
                <li onClick={() => handleMenuClick("kids")}>
                    <Link style={{ textDecoration:'none' }} to='/kids'>Kids</Link>
                    {!isSpecialPage && menu === "kids" ? <hr /> : null}
                </li>
            </ul>
            <div className='nav-login-cart'>
                <Link to='/login' onClick={handleCartClick}><button>Login</button></Link>
                <Link to='/cart' onClick={handleCartClick}><img src={cart_icon} alt="" /></Link>
                <div className="nav-cart-count">{getTotalCartItems()}</div>
            </div>
        </div>
    );
};

export default Navbar;
