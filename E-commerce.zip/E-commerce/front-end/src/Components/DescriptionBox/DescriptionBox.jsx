import React from 'react'
import './DescriptionBox.css'

const DescriptionBox = () => {
  return (
    <div className='descriptionbox'>
        <div className="description-navigator">
            <div className="description-nav-box">Description</div>
            <div className="description-nav-box fade">Reviews (128)</div>
        </div>
        <div className="descriptionbox-description">
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusamus omnis ex, architecto harum, cum quos neque debitis maxime explicabo quidem odit deleniti minima qui consequuntur error quisquam vero placeat mollitia!</p>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusamus omnis ex, architecto harum, cum quos neque debitis maxime explicabo quidem odit deleniti minima qui consequuntur error quisquam vero placeat mollitia!</p>
        </div>
    </div>
  )
}

export default DescriptionBox